# AP Invoice Automation — Synthetic Dataset

## Scope
Reproducible synthetic AP dataset covering vendor/PO/receipt/invoice master and transaction data, matching bridge, append-only invoice events, approvals, payments, and separate ground truth.

## Baseline volumes
- Vendors: 300
- Purchase orders: 1,500
- PO lines: 2,200
- Goods receipts: 1,800
- Invoices: 2,000
- Invoice lines: 2000
- Ground-truth labels: 2,000

## Scenario mix
- Clean: 70%
- Price variance: 10%
- Quantity mismatch: 8%
- Duplicate invoice: 5%
- Missing receipt: 4%
- Tax/vendor errors: 3%

## Matching policy (starter policy)
- Price: exact match in this baseline; configurable tolerance can be added in the rules engine.
- Quantity: billed quantity must not exceed accepted receipt quantity or PO quantity.
- Tax: invoice tax code must match PO line tax code.
- Duplicate: vendor + vendor_invoice_number must be unique.
- Date: invoice date must not precede PO date.
- Arithmetic: header subtotal/tax/grand total must reconcile to invoice lines.
- Vendor: vendor must be ACTIVE.
- Payment-ready: all matching checks pass, approval is APPROVED, and vendor is ACTIVE.

## Files
CSV and JSON exports are supplied for every table. `schema.sql` defines relational tables and foreign keys. `data_dictionary.json` documents keys and field contracts. `ground_truth.csv/json` is an evaluation-only label file and must not be included in model input features. `InvoiceEvent.csv` is append-only state history.

## Relationships
Vendor 1:N PurchaseOrder; PurchaseOrder 1:N PurchaseOrderLine; PurchaseOrder 1:N GoodsReceipt; GoodsReceipt 1:N GoodsReceiptLine; PurchaseOrderLine 1:N GoodsReceiptLine; Vendor 1:N Invoice; PurchaseOrder 1:N Invoice (optional PO); Invoice 1:N InvoiceLine; Invoice N:M GoodsReceiptLine through InvoiceReceiptMatch; Invoice 1:N Approval and Payment (at most one active record in this starter); Invoice 1:N InvoiceEvent.

## Reproducibility
Seed: 20261022. The full-scale dataset is deterministic. A generator command and checksums are included. All generated records use synthetic IDs and synthetic document URIs.

## Important implementation note
The starter dataset provides invoice intake and deterministic outcomes, but production OCR/LLM extraction, human exception work queues, configurable tolerance management, and payment-rail integration are represented as system extension points—not connected to real services.
